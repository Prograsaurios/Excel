/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cotizalud.GUI;

import cotizalud.Contexto.Medicamento;
import cotizalud.GUI.util.Tabla_Medicamentos;
import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author raguileoam
 */
public class GUI_Medicamentos extends JTable {

    /**
     *Constructor de la clase GUI_Medicamentos
     */
    public GUI_Medicamentos() {
        super();
        this.setAutoCreateRowSorter(true);
        this.getTableHeader().setReorderingAllowed(false);
        this.setModel(new Tabla_Medicamentos());
    }

    /**
     *
     * @param region
     * @param medicamento
     * @param farmacia
     * @return
     * Carga los medicamentos, que fueron encontrados en la base de datos , en una tabla
     */
    public ArrayList<Medicamento> loadMedicamentos(String region, String medicamento, String farmacia) {
        try {
            ArrayList<Medicamento> medic= new ArrayList<>();
            Medicamento med = new Medicamento(region, medicamento, farmacia);
            ResultSet rs = med.resp("MEDS");
            if(rs.next()==false){
                JOptionPane.showMessageDialog(null,"no se ha encontrado ningun remedio");
            }
            while (rs.next()) {
                Medicamento med1=new Medicamento();
                med1.setCodigo(rs.getInt("id"));
                med1.setMedicamento(rs.getString("medicamento"));
                med1.setDosis(rs.getString("dosis"));
                med1.setPresentacion(rs.getString("presentación"));
                med1.setMarca(rs.getString("marca"));
                med1.setFarmacia(rs.getString("farmacía"));
                med1.setPrecio(rs.getInt("precio"));
                med1.setDireccion(rs.getString("dirección"));
                med1.setComuna(rs.getString("comuna"));
                med1.setRegion(rs.getString("región"));
                medic.add(med1);
            }
            med.getDb().desconectar();
            return medic;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
    }
    public DefaultTableModel cargarMedicamentos(ArrayList<Medicamento> medicamentos){
        DefaultTableModel dtm = new Tabla_Medicamentos();
        for (int i=0; i<medicamentos.size();i++){
        Object[] obj = new Object[10];
        obj[0] = medicamentos.get(i).getCodigo();
        obj[1] = medicamentos.get(i).getMedicamento();
        obj[2] = medicamentos.get(i).getDosis();
        obj[3] = medicamentos.get(i).getPresentacion();
        obj[4] = medicamentos.get(i).getMarca();
        obj[5] = medicamentos.get(i).getFarmacia();
        obj[6] = medicamentos.get(i).getPrecio();
        obj[7] = medicamentos.get(i).getDireccion();
        obj[8] = medicamentos.get(i).getComuna();
        obj[9] = medicamentos.get(i).getRegion();    
        dtm.addRow(obj);
        }
        return dtm;
    }
}
