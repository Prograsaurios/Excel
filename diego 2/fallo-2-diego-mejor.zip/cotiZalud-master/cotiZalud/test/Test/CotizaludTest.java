/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import cotizalud.Contexto.Medicamento;
import cotizalud.GUI.GUI_Busqueda;
import cotizalud.GUI.GUI_Medicamentos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author diegosaurio
 */
public class CotizaludTest {
    
    public CotizaludTest() {
    }
    @Test
    public void test1() throws SQLException{
    GUI_Medicamentos gmed= new GUI_Medicamentos();
        String region="Arica";
        String medicamento="ACNOTIN";
        String farmacia="Cruz Verde";
        Medicamento med = new Medicamento(region, medicamento, farmacia);
        med.setCodigo(3517);
        med.setMedicamento(medicamento);
        med.setDosis("10 mg");
        med.setPresentacion("30 CÁPSULAS BLANDAS");
        med.setMarca("LABORATORIO BAGÓ DE CHILE S.A.");
        med.setFarmacia(farmacia);
        med.setPrecio(29390);
        med.setDireccion("21 de Mayo 299");
        med.setComuna(region);
        med.setRegion(region);
        ArrayList<Medicamento> med1= new ArrayList<Medicamento>();
        med1.add(med);
        ArrayList<Medicamento> med2=gmed.loadMedicamentos(region, medicamento, farmacia);
        assertEquals(med1, med);
    }
   
   } 

